#include <stdio.h>

int main(void) {
  /* below is going to be step 1 variables*/
   double cCost;
   int width;
   int length;
   double waste = 0.20;
   /* below is going to be step 2 variables*/
   double laborCost = 0.75;
   /* below is going to be step 3 variables*/
   double taxRate = 0.07;
   double Cost;
   /* SECOND ORDER below going to be step 1 variables*/
   double cCost1;
   int width1;
   int length1;
   double Cost1;
   /* THIRD ORDER below */
   double cCost2;
   int width2;
   int length2;
   double Cost2;
   
   /* output variable(s) from step 1 */
   int roomSize;
   double carpet;
   /* output variable(s) from step 2 */
   double labor;
   /* output variable(s) from step 3 */
   double tax;
   /*SECOND ORDER output variables*/
   int roomSize1;
   double carpet1;
   double labor1;
   double tax1;
   double totalSales;
   
   /*THIRD ORDER out variables */
   int roomSize2;
   double carpet2;
   double labor2;
   double tax2;
   
   
   scanf("%lf", &cCost);
   scanf("%d", &width);
   scanf("%d", &length);
   /*second order*/
   scanf("%lf", &cCost1);
   scanf("%d", &width1);
   scanf("%d", &length1);
   /*third order */
   scanf("%lf", &cCost2);
   scanf("%d", &width2);
   scanf("%d", &length2);
   

   /* below expression step one */
   roomSize = (width * length);
   carpet = (roomSize * cCost)+((roomSize * cCost) * (waste));
   /*below expression from step two */
   labor = (roomSize * laborCost);
   /*below expression from step three */
   tax = (carpet + labor) * (taxRate);
   Cost = (carpet + labor + tax);
   /*SECOND ORDER */
   roomSize1 = (width1 * length1);
   carpet1 = (roomSize1 * cCost1)+((roomSize1 * cCost1) *(waste));
   labor1 = (roomSize1 * laborCost);
   tax1 = (carpet1 + labor1) * (taxRate);
   Cost1 = (carpet1 + labor1 + tax1);
   /*THIRD ORDER*/
   roomSize2 = (width2 * length2);
   carpet2 = (roomSize2 * cCost2)+((roomSize2 * cCost2) * (waste));
   labor2 = (roomSize2 * laborCost);
   tax2 = (carpet2 + labor2) * (taxRate);
   Cost2 = (carpet2 + labor2 + tax2);
   totalSales = (Cost + Cost1 + Cost2);
   
   
   printf("Order #1\n");
   printf("Room: %d sq ft\n",roomSize);
   printf("Carpet: $%.2lf\n",carpet);
   printf("Labor: $%.2lf\n",labor);
   printf("Tax: $%.2lf\n",tax);
   printf("Cost: $%.2lf\n",Cost);
   printf("\n");
   
   /*Below is going to be order 2*/
   printf("Order #2\n");
   printf("Room: %d sq ft\n",roomSize1);
   printf("Carpet: $%.2lf\n",carpet1);
   printf("Labor: $%.2lf\n",labor1);
   printf("Tax: $%.2lf\n",tax1);
   printf("Cost: $%.2lf\n",Cost1);
   printf("\n");
   
   /*Below is going to be order 3*/
   printf("Order #3\n");
   printf("Room: %d sq ft\n",roomSize2);
   printf("Carpet: $%.2lf\n",carpet2);
   printf("Labor: $%.2lf\n",labor2);
   printf("Tax: $%.2lf\n",tax2);
   printf("Cost: $%.2lf\n",Cost2);
   
   printf("\n");
   printf("Total Sales: $%.2lf\n",totalSales);
 
  return 0;
}